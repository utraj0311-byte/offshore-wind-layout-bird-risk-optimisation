# IEA 15 MW source files for the final bird collision model

This archive contains unmodified, version-pinned source files for the IEA Wind
15 MW reference turbine. It is intended to be uploaded as one file to the
final-model chat. The FLORIS file defines the turbine used for AEP; the IEA
files supply the additional blade and operating inputs requested for the Band
blade-strike stage. No blade-strike calculation or choice of radial conversion
has been made in this archive.

## File and parameter map

| File | Version and origin | Relevant inputs |
| --- | --- | --- |
| `floris_iea_15MW_v4.6.5.yaml` | FLORIS v4.6.5, `floris/turbine_library/iea_15MW.yaml` | `turbine_type: iea_15MW`; hub height 150 m; rotor diameter 242.24 m; tabulated wind speed, power and thrust coefficient used by FLORIS. Its selected `operation_model` is `cosine-loss`. |
| `IEA-15-240-RWT_AeroDyn15_blade.dat` | IEA Wind Task 37 reference turbine v1.1.18 | 50 blade nodes: `BlSpn` [m] from blade root, `BlChord` [m], `BlTwist` [deg], and additional aerodynamic geometry. |
| `IEA-15-240-RWT-Monopile_ElastoDyn.dat` | IEA Wind Task 37 monopile v1.1.18 | `NumBl = 3`, `HubRad = 3.97 m`, `TipRad = 120.97 m`, `PreCone = -4 deg`. Its `RotSpeed = 7.55 rpm` is an *initial/fixed input*, not an operating RPM schedule. |
| `IEA-15-240-RWT_tabular.xlsx` | IEA Wind Task 37 v1.1.18 | On the `Rotor Performance` sheet: `Wind [m/s]`, `Pitch [deg]`, `Rotor Speed [rpm]`, power, thrust and coefficients. `Overview` also gives three blades and hub height 150 m. |

The FLORIS YAML itself attributes its power and thrust data to the IEA tabular
workbook, with small above-rated power variations removed and generator
efficiency set to 100% in FLORIS. It contains a `rated_rpm: 7.55` entry under
`controller_dependent_turbine_parameters`, but it does not contain a
wind-speed-dependent RPM or blade-pitch schedule. The `cp_ct_data_file` named
in that nested block refers to demonstrative controller-dependent surfaces;
the selected FLORIS operation model is `cosine-loss`.

## Geometry and operating-data consistency checks

- Use the thesis's actual FLORIS rotor diameter of **242.24 m** (radius
  **121.12 m**) when reproducing its AEP/rotor-disc assumptions. The earlier
  Jensen prototype's 240 m diameter is not the later FLORIS definition.
- The pinned OpenFAST ElastoDyn input gives `HubRad = 3.97 m` and
  `TipRad = 120.97 m`; the AeroDyn blade spans 0 to approximately 117.00 m
  from the blade root. In that input's span convention, the blade-node radial
  coordinate is `HubRad + BlSpn`. Do not silently identify its outer radius
  with FLORIS's 121.12 m.
- The pinned IEA workbook's `Overview` reports a rotor diameter of
  **241.35064632 m**, a further difference from FLORIS's 242.24 m. Preserve
  each source's value and document any mapping between blade stations,
  workbook performance and the collision disc before running the final model.
- The workbook `Rotor Performance` entries cover wind speeds from 3 to
  25 m/s. The IEA authors state that this table is an **idealised WISDEM
  steady-state** result, not a controller simulation. Its RPM and pitch
  values are defensible *source-based modelling inputs*, but are not measured
  operating data or values already supplied by FLORIS. Interpolate at the
  model's actual wind-speed bins only after documenting the chosen rule.
- `BlTwist` is blade geometry and `Pitch [deg]` is a collective operating
  setting. Keep their conventions distinct when implementing the Band
  collision equation. Do not set every operating wind speed to 7.55 rpm.

## Exact download URLs

- FLORIS v4.6.5 turbine definition: https://raw.githubusercontent.com/NatLabRockies/floris/v4.6.5/floris/turbine_library/iea_15MW.yaml
- IEA blade geometry, v1.1.18: https://raw.githubusercontent.com/IEAWindSystems/IEA-15-240-RWT/v1.1.18/OpenFAST/IEA-15-240-RWT/IEA-15-240-RWT_AeroDyn15_blade.dat
- IEA monopile ElastoDyn input, v1.1.18: https://raw.githubusercontent.com/IEAWindSystems/IEA-15-240-RWT/v1.1.18/OpenFAST/IEA-15-240-RWT-Monopile/IEA-15-240-RWT-Monopile_ElastoDyn.dat
- IEA tabular workbook, v1.1.18: https://raw.githubusercontent.com/IEAWindSystems/IEA-15-240-RWT/v1.1.18/Documentation/IEA-15-240-RWT_tabular.xlsx

Background for citation and interpretation:

- Gaertner et al. (2020), *Definition of the IEA 15-Megawatt Offshore
  Reference Wind Turbine*, NREL/TP-5000-75698:
  https://docs.nlr.gov/docs/fy20osti/75698.pdf
- IEA repository release notes, including the corrected 242.24 m nominal
  diameter: https://github.com/IEAWindSystems/IEA-15-240-RWT/blob/master/ReleaseNotes.md
- IEA authors' FAQ on the idealised workbook performance and the rotor
  diameter discrepancy:
  https://github.com/IEAWindSystems/IEA-15-240-RWT/wiki/Frequently-Asked-Questions-(FAQ)

## SHA-256 of the four unmodified source files

```text
be58f41b85580db71c66fc2de1eaafc768e0cb96b206d95c7a61aeaf3c48e934  IEA-15-240-RWT-Monopile_ElastoDyn.dat
ed8eaaa11813946594bc791e9c808eba18d8078bf9409956814a00ba3c3ccef0  IEA-15-240-RWT_AeroDyn15_blade.dat
9ed6ee219a97c443d0b900498e3ef4fefa12d855d9a7c9e4c5b9bc0702b9078a  IEA-15-240-RWT_tabular.xlsx
93d2bcfcb619b1819efe8149ce9e8231656e51a29f2ae5c1079a46e339f02feb  floris_iea_15MW_v4.6.5.yaml
```
